

$xFolder = "C:\apl\!TOOLS\eZimmerman" 


Clear-host
AAA-Logo

"`t{0}" -f $xFolder
""

UI-File-Tree -xPath $xFolder -xFilter "*.exe"



