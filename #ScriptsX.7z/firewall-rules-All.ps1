netsh advfirewall firewall show rule name=all verbose
