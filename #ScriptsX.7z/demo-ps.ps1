
:MAIN
	AAA-Obs %0



:OBS

	Proof-of-Concept demo scripts
	Convention-over-Configuration

	AAA-Check will check for ecosystem
	(environment + interpreters + ... )

	demo-cm .... Command/Batch .cmd/.bat demo
	demo-ps .... Powershell
	demo-c# .... C#/Roslyn interpreter
	demo-py .... Python demo
	demo-js .... Javascript Deno/Node/JScript/...
	demo-ht .... HTML/AJAX demo-cm
	demo-vs .... VBScript
	demo-cs .... CScript
	demo-lua ... Lua


