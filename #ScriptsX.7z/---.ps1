###############################################################################
#
# Self lister for AAA-* auto-discovery
#


AAA-log
AAA-Script-ListX "-"

