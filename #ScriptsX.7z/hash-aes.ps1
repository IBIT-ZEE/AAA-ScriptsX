hash-aes $args
