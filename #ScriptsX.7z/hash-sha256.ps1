hash-sha256 $args
