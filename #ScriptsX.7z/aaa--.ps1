###############################################################################
#
# Self lister for AAA-* auto-discovery
#
#	AAA-Script-List/AAA-0-Base.ps1
#		Autodecision for Files/Groups
#			if <this-filename> ends in "-"  is Files
#			if <this-filename> ends in "--" is Groups

AAA-Log
AAA-Script-List

