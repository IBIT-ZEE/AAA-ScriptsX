aaa-obs route0.cmd
