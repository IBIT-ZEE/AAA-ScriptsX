###############################################################################
#
# Self lister for AAA-* auto-discovery
#


AAA-Log
AAA-Script-List


"
	*****************************
	see also data-*
	for simple flat-file AAA/Data
	*****************************
"
