Convert-fromHexadecimal $args
