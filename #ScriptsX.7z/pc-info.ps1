
<#


WindowsBuildLabEx                                       : 17763.1.amd64fre.rs5_release.
                                                          180914-1434
WindowsCurrentVersion                                   : 6.3
WindowsEditionId                                        : Professional
WindowsInstallationType                                 : Client
WindowsInstallDateFromRegistry                          : 2018-12-18 23:15:37
WindowsProductId                                        : 00331-10000-00001-AA452
WindowsProductName                                      : Windows 10 Pro
WindowsRegisteredOrganization                           : 
WindowsRegisteredOwner                                  : OEM
WindowsSystemRoot                                       : C:\Windows
WindowsVersion                                          : 1809
BiosCharacteristics                                     : {7, 10, 11, 12...}
BiosBIOSVersion                                         : {ALASKA - 1072009, BIOS 
                                                          Date: 11/15/18 16:30:54 Ver: 
                                                          05.0000D}
BiosBuildNumber                                         : 
BiosCaption                                             : BIOS Date: 11/15/18 16:30:54 
                                                          Ver: 05.0000D
BiosCodeSet                                             : 
BiosCurrentLanguage                                     : en|US|iso8859-1
BiosDescription                                         : BIOS Date: 11/15/18 16:30:54 
                                                          Ver: 05.0000D
BiosEmbeddedControllerMajorVersion                      : 255
BiosEmbeddedControllerMinorVersion                      : 255
BiosFirmwareType                                        : Bios
BiosIdentificationCode                                  : 
BiosInstallableLanguages                                : 9
BiosInstallDate                                         : 
BiosLanguageEdition                                     : 
BiosListOfLanguages                                     : {en|US|iso8859-1, 
                                                          fr|FR|iso8859-1, 
                                                          zh|TW|unicode, 
                                                          zh|CN|unicode...}
BiosManufacturer                                        : American Megatrends Inc.
BiosName                                                : BIOS Date: 11/15/18 16:30:54 
                                                          Ver: 05.0000D
BiosOtherTargetOS                                       : 
BiosPrimaryBIOS                                         : True
BiosReleaseDate                                         : 2018-11-15 00:00:00
BiosSeralNumber                                         : System Serial Number
BiosSMBIOSBIOSVersion                                   : 1101
BiosSMBIOSMajorVersion                                  : 2
BiosSMBIOSMinorVersion                                  : 8
BiosSMBIOSPresent                                       : True
BiosSoftwareElementState                                : Running
BiosStatus                                              : OK
BiosSystemBiosMajorVersion                              : 5
BiosSystemBiosMinorVersion                              : 13
BiosTargetOperatingSystem                               : 0
BiosVersion                                             : ALASKA - 1072009
CsAdminPasswordStatus                                   : Unknown
CsAutomaticManagedPagefile                              : True
CsAutomaticResetBootOption                              : True
CsAutomaticResetCapability                              : True
CsBootOptionOnLimit                                     : 
CsBootOptionOnWatchDog                                  : 
CsBootROMSupported                                      : True
CsBootStatus                                            : {0, 0, 0, 0...}
CsBootupState                                           : Normal boot
CsCaption                                               : ZEE-PC
CsChassisBootupState                                    : Safe
CsChassisSKUNumber                                      : Default string
CsCurrentTimeZone                                       : 0
CsDaylightInEffect                                      : False
CsDescription                                           : AT/AT COMPATIBLE
CsDNSHostName                                           : ZEE-PC
CsDomain                                                : IBIT
CsDomainRole                                            : StandaloneWorkstation
CsEnableDaylightSavingsTime                             : True
CsFrontPanelResetStatus                                 : Unknown
CsHypervisorPresent                                     : True
CsInfraredSupported                                     : False
CsInitialLoadInfo                                       : 
CsInstallDate                                           : 
CsKeyboardPasswordStatus                                : Unknown
CsLastLoadInfo                                          : 
CsManufacturer                                          : System manufacturer
CsModel                                                 : System Product Name
CsName                                                  : ZEE-PC
CsNetworkAdapters                                       : {LAN1, LAN2, LAN0, vEthernet 
                                                          (Default Switch)...}
CsNetworkServerModeEnabled                              : True
CsNumberOfLogicalProcessors                             : 12
CsNumberOfProcessors                                    : 1
CsProcessors                                            : {Intel(R) Core(TM) i7-8700 
                                                          CPU @ 3.20GHz}
CsOEMStringArray                                        : {Default string, Default 
                                                          string, NOVA, Default 
                                                          string...}
CsPartOfDomain                                          : False
CsPauseAfterReset                                       : -1
CsPCSystemType                                          : Desktop
CsPCSystemTypeEx                                        : Desktop
CsPowerManagementCapabilities                           : 
CsPowerManagementSupported                              : 
CsPowerOnPasswordStatus                                 : Unknown
CsPowerState                                            : Unknown
CsPowerSupplyState                                      : Safe
CsPrimaryOwnerContact                                   : 
CsPrimaryOwnerName                                      : OEM
CsResetCapability                                       : Other
CsResetCount                                            : -1
CsResetLimit                                            : -1
CsRoles                                                 : {LM_Workstation, LM_Server, 
                                                          NT}
CsStatus                                                : OK
CsSupportContactDescription                             : 
CsSystemFamily                                          : To be filled by O.E.M.
CsSystemSKUNumber                                       : ASUS_MB_CNL
CsSystemType                                            : x64-based PC
CsThermalState                                          : Safe
CsTotalPhysicalMemory                                   : 34198786048
CsPhyicallyInstalledMemory                              : 33554432
CsUserName                                              : ZEE-PC\ZEEX
CsWakeUpType                                            : PCIPME
CsWorkgroup                                             : IBIT
OsName                                                  : Microsoft Windows 10 Pro
OsType                                                  : WINNT
OsOperatingSystemSKU                                    : 48
OsVersion                                               : 10.0.17763
OsCSDVersion                                            : 
OsBuildNumber                                           : 17763
OsHotFixes                                              : {KB4519565, KB4465065, 
                                                          KB4470502, KB4470788...}
OsBootDevice                                            : \Device\HarddiskVolume4
OsSystemDevice                                          : \Device\HarddiskVolume5
OsSystemDirectory                                       : C:\Windows\system32
OsSystemDrive                                           : C:
OsWindowsDirectory                                      : C:\Windows
OsCountryCode                                           : 44
OsCurrentTimeZone                                       : 0
OsLocaleID                                              : 0809
OsLocale                                                : en-GB
OsLocalDateTime                                         : 2019-11-27 20:09:46
OsLastBootUpTime                                        : 2019-11-27 14:09:47
OsUptime                                                : 05:59:58.9536598
OsBuildType                                             : Multiprocessor Free
OsCodeSet                                               : 1252
OsDataExecutionPreventionAvailable                      : True
OsDataExecutionPrevention32BitApplications              : True
OsDataExecutionPreventionDrivers                        : True
OsDataExecutionPreventionSupportPolicy                  : OptIn
OsDebug                                                 : False
OsDistributed                                           : False
OsEncryptionLevel                                       : 256
OsForegroundApplicationBoost                            : Maximum
OsTotalVisibleMemorySize                                : 33397252
OsFreePhysicalMemory                                    : 24366188
OsTotalVirtualMemorySize                                : 38377988
OsFreeVirtualMemory                                     : 28667632
OsInUseVirtualMemory                                    : 9710356
OsTotalSwapSpaceSize                                    : 
OsSizeStoredInPagingFiles                               : 4980736
OsFreeSpaceInPagingFiles                                : 4980736
OsPagingFiles                                           : {D:\pagefile.sys}
OsHardwareAbstractionLayer                              : 10.0.17763.831
OsInstallDate                                           : 2018-12-18 23:15:37
OsManufacturer                                          : Microsoft Corporation
OsMaxNumberOfProcesses                                  : 4294967295
OsMaxProcessMemorySize                                  : 137438953344
OsMuiLanguages                                          : {en-GB}
OsNumberOfLicensedUsers                                 : 0
OsNumberOfProcesses                                     : 228
OsNumberOfUsers                                         : 2
OsOrganization                                          : 
OsArchitecture                                          : 64-bit
OsLanguage                                              : en-GB
OsProductSuites                                         : {TerminalServicesSingleSessio
                                                          n}
OsOtherTypeDescription                                  : 
OsPAEEnabled                                            : 
OsPortableOperatingSystem                               : False
OsPrimary                                               : True
OsProductType                                           : WorkStation
OsRegisteredUser                                        : OEM
OsSerialNumber                                          : 00331-10000-00001-AA452
OsServicePackMajorVersion                               : 0
OsServicePackMinorVersion                               : 0
OsStatus                                                : OK
OsSuites                                                : {TerminalServices, TerminalSe
                                                          rvicesSingleSession}
OsServerLevel                                           : 
KeyboardLayout                                          : pt-PT
TimeZone                                                : (UTC+00:00) Dublin, 
                                                          Edinburgh, Lisbon, London
LogonServer                                             : \\ZEE-PC
PowerPlatformRole                                       : Desktop
HyperVisorPresent                                       : True
HyperVRequirementDataExecutionPreventionAvailable       : 
HyperVRequirementSecondLevelAddressTranslation          : 
HyperVRequirementVirtualizationFirmwareEnabled          : 
HyperVRequirementVMMonitorModeExtensions                : 
DeviceGuardSmartStatus                                  : Off
DeviceGuardRequiredSecurityProperties                   : 
DeviceGuardAvailableSecurityProperties                  : 
DeviceGuardSecurityServicesConfigured                   : 
DeviceGuardSecurityServicesRunning                      : 
DeviceGuardCodeIntegrityPolicyEnforcementStatus         : 
DeviceGuardUserModeCodeIntegrityPolicyEnforcementStatus : 

#>


