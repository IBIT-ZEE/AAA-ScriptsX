hash-sha1 $args
