Convert-toBase64 $args
