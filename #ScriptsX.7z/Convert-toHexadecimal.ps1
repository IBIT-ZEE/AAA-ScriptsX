Convert-toHexadecimal $args


