###############################################################################
#
# Self lister for AAA-* auto-discovery
#


Param( $xPC=".", $xCred="OEM" )

AAA-Log
# AAA-Script-List

# $xZEEX = Get-Credential ZEEX;

# Enter-PSSession -ComputerName $xPC -Credential $xCred

$xPC

$xCred






